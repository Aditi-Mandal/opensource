# Opal Kelly Design Resources

Components, examples and tools provided to facilitate usage of Opal Kelly products.

## [ExampleProjects](/ExampleProjects)
Full featured example projects

## [HDLComponents](/HDLComponents)
Component usage examples

## [Petalinux](/Petalinux)
Petalinux project source and device example applications